<?php get_header(); ?>

  <!-- All content and pages are in their respective templates and collected in page-all.php -->

<?php get_footer(); ?>
